import os
import smtplib
import time
import requests
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime

# Email configurations
EMAIL_ADDRESS = "tanmaytambat01@gmail.com"
EMAIL_PASSWORD = "lumr ehti ahew zrvs"
TO_EMAIL = "tanmaytambat4@gmail.com"
SUBJECT = "Emergency Alert"
LOCATION_API = "http://ip-api.com/json"  # Mock location from IP

# Function to capture photo
def capture_photo():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    photo_filename = f"photo_{timestamp}.jpg"
    os.system(f"fswebcam -r 640x480 --jpeg 85 -D 1 {photo_filename}")
    return photo_filename

# Function to get current location
def get_location():
    try:
        response = requests.get(LOCATION_API)
        data = response.json()
        if data['status'] == 'success':
            return f"Lat: {data['lat']}, Lon: {data['lon']}, City: {data['city']}, Country: {data['country']}"
        else:
            return "Location not found."
    except:
        return "Location service unavailable."

# Function to send email
def send_email(photo_filename, location):
    msg = MIMEMultipart()
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = TO_EMAIL
    msg['Subject'] = SUBJECT

    body = f"Emergency alert sent from Raspberry Pi.\nLocation: {location}"
    msg.attach(MIMEText(body, 'plain'))

    # Attach the photo
    attachment = open(photo_filename, "rb")
    part = MIMEBase('application', 'octet-stream')
    part.set_payload(attachment.read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', f"attachment; filename= {photo_filename}")
    msg.attach(part)

    # Sending the email
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        text = msg.as_string()
        server.sendmail(EMAIL_ADDRESS, TO_EMAIL, text)
        server.quit()
        print(f"Email sent successfully to {TO_EMAIL}")
    except Exception as e:
        print(f"Failed to send email: {e}")

# Simulating a button press
def button_press():
    print("Press Enter to simulate button press...")
    input()  # Simulate the button press

    # Capture photo
    photo_filename = capture_photo()
    print(f"Photo captured: {photo_filename}")

    # Get location
    location = get_location()
    print(f"Location fetched: {location}")

    # Send email with the photo and location
    send_email(photo_filename, location)

# Main program
if __name__ == "__main__":
    while True:
        button_press()  # Simulate the button press for now
        print("Waiting for next alert...")
        time.sleep(10)  # Cooldown between alerts
